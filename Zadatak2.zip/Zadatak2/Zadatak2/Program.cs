﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;

namespace Zadatak2
{
    class Program
    {
        static IWebDriver driver = new ChromeDriver();

        static void Main()
        {
            driver.Navigate().GoToUrl("http://demowebshop.tricentis.com/");
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);

            ValidRegistration registration = new ValidRegistration(driver);
            registration.Run();


            //RequiredFieldNotFilled requiredFieldNot = new RequiredFieldNotFilled(driver);
            //requiredFieldNot.Run();

            //InFieldPasswordTypeLessThanSixCharacter inFieldPasswordTypeLessThanSixCharacter = new InFieldPasswordTypeLessThanSixCharacter(driver);
            //inFieldPasswordTypeLessThanSixCharacter.Run();

            //    IncorrectConfirmPassword incorrectConfirmPassword = new IncorrectConfirmPassword(driver);
            //    incorrectConfirmPassword.Run();
        }
    }
}
