﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Zadatak2
{
    
    class RequiredFieldNotFilled
    {

        static IWebElement name;
        static IWebElement radioButton;
        IWebDriver driver;

        public RequiredFieldNotFilled(IWebDriver d)
        {
            driver = d;
        }

        public void Run()
        {
            driver.FindElement(By.XPath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).Click();


            radioButton = driver.FindElement(By.XPath("//*[@id=\"gender-male\"]"));
            radioButton.Click();


            name = driver.FindElement(By.XPath("//*[@id=\"FirstName\"]"));
            name.SendKeys("user");

            Console.WriteLine("Hello");
            Thread.Sleep(3000);

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);



            driver.FindElement(By.Id("Email")).SendKeys("ab2c@mail.com");

            driver.FindElement(By.Id("Password")).SendKeys("101010");

            driver.FindElement(By.Id("ConfirmPassword")).SendKeys("101010");
        }
    }
}
