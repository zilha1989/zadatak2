﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace Zadatak2
{
    class ValidRegistration
    {
        IWebDriver driver;

        public ValidRegistration(IWebDriver d)
        {
            driver = d;

        }

        public void Run()
        {
            driver.FindElement(By.XPath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).Click();

            driver.FindElement(By.XPath("//*[@id=\"gender-male\"]")).Click();

            driver.FindElement(By.XPath("//*[@id=\"FirstName\"]")).SendKeys("test2");

            driver.FindElement(By.XPath("//*[@id=\"LastName\"]")).SendKeys("test2");

            driver.FindElement(By.Id("Email")).SendKeys("ab2c@mail.com");

            driver.FindElement(By.Id("Password")).SendKeys("101010");

            driver.FindElement(By.Id("ConfirmPassword")).SendKeys("101010");


        }
    }
}
